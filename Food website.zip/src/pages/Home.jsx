import Popular from "../components/Popular";
import Vegie from "../components/Vegie";


import React from 'react'

function Home() {
  return (
    <div>
        <Vegie />
        <Popular/>
    </div>
  )
}

export default Home